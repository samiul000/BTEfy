#include "BTEfyDebug.h"

BTEfyDebug *BTEfyDebug::_self = nullptr;

/** Global instance -> use BTEfy.println(...) anywhere. */
BTEfyDebug BTEfy;

void BTEfyDebug::begin(const char *deviceName, const char *version) {
  _version = version;
  _self = this;

  NimBLEDevice::init(deviceName);
  NimBLEServer *server = NimBLEDevice::createServer();
  NimBLEService *uart = server->createService(BTEFY_SERVICE_UUID);

  _tx = uart->createCharacteristic(BTEFY_TX_UUID, NIMBLE_PROPERTY::NOTIFY);
  NimBLECharacteristic *rx = uart->createCharacteristic(
      BTEFY_RX_UUID, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  rx->setCallbacks(new RxCallbacks());

  uart->start();
  NimBLEAdvertising *adv = NimBLEDevice::getAdvertising();
  adv->addServiceUUID(BTEFY_SERVICE_UUID);
  adv->start();
}

void BTEfyDebug::mirrorSerial(bool on) { _mirror = on; }

bool BTEfyDebug::connected() {
  // NimBLE 2.x dropped getSubscribedCount(); a connected peer is close enough.
  NimBLEServer *server = NimBLEDevice::getServer();
  return server && server->getConnectedCount() > 0;
}

void BTEfyDebug::println(const char *msg) { sendLine(msg); }
void BTEfyDebug::println(const String &msg) { sendLine(msg.c_str()); }
void BTEfyDebug::println(int v) { sendLine(String(v).c_str()); }
void BTEfyDebug::println(float v, int decimals) {
  sendLine(String(v, decimals).c_str());
}

void BTEfyDebug::print(const char *msg) { sendRaw(msg); }
void BTEfyDebug::print(const String &msg) { sendRaw(msg.c_str()); }

void BTEfyDebug::log(const char *tag, const char *msg) {
  char line[128];
  snprintf(line, sizeof(line), "[%s] %s", tag, msg);
  sendLine(line);
}

void BTEfyDebug::metric(const char *key, float value, int decimals) {
  char line[64];
  snprintf(line, sizeof(line), "%s=%.*f", key, decimals, value);
  sendLine(line);
}

void BTEfyDebug::logf(const char *tag, const char *fmt, ...) {
  char body[112];
  va_list args;
  va_start(args, fmt);
  vsnprintf(body, sizeof(body), fmt, args);
  va_end(args);
  log(tag, body);
}

void BTEfyDebug::RxCallbacks::onWrite(NimBLECharacteristic *chr,
                                      NimBLEConnInfo &) {
  if (!_self) return;
  String cmd = chr->getValue().c_str();
  cmd.trim();
  if (cmd == "PING") {
    _self->sendLine("PONG");
  } else if (cmd == "STATUS") {
    char line[48];
    snprintf(line, sizeof(line), "STATUS=OK,UPTIME=%lu", millis() / 1000);
    _self->sendLine(line);
  } else if (cmd == "VERSION") {
    char line[48];
    snprintf(line, sizeof(line), "VERSION=%s", _self->_version);
    _self->sendLine(line);
  } else if (cmd.length() > 0) {
    _self->sendLine(("ECHO:" + cmd).c_str());
  }
}

void BTEfyDebug::sendLine(const char *msg) {
  if (_mirror) Serial.println(msg);
  if (!_tx || !connected()) return;
  // Chunk to the BLE payload size with a small gap between chunks.
  size_t len = strlen(msg);
  for (size_t i = 0; i < len; i += BTEFY_CHUNK_SIZE) {
    size_t n = len - i < BTEFY_CHUNK_SIZE ? len - i : BTEFY_CHUNK_SIZE;
    _tx->notify((const uint8_t *)(msg + i), n);
    if (i + n < len) delay(5);
  }
  _tx->notify((const uint8_t *)"\n", 1);
}

void BTEfyDebug::sendRaw(const char *msg) {
  if (_mirror) Serial.print(msg);
  if (!_tx || !connected()) return;
  _tx->notify((const uint8_t *)msg, strlen(msg));
}
