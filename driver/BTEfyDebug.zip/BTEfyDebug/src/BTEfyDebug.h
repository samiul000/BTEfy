/*
 * BTEfyDebug —> BLE debug driver for the BTEfy webpage.
 *
 * Install: Sketch -> Include Library -> Add .ZIP Library -> select the
 * BTEfyDebug folder (zipped). Then:
 *
 *     #include <BTEfyDebug.h>
 *
 *     void setup() {
 *       BTEfy.begin("MyRobot");          // BLE name shown in the webpage picker
 *     }
 *
 *     void loop() {
 *       BTEfy.println("hello");          // -> BTEfy terminal
 *       BTEfy.log("WIFI", "connected");  // -> [WIFI] connected
 *       BTEfy.metric("TEMP", 25.4);      // -> TEMP=25.40, auto-plotted
 *     }
 *
 * Requires the NimBLE-Arduino library. Answers PING / STATUS / VERSION
 * automatically and mirrors everything to USB Serial by default.
 */

#pragma once

#include <Arduino.h>
#include <NimBLEDevice.h>

// Nordic UART Service (must match BTEfy's default BLE profile)
#define BTEFY_SERVICE_UUID "6e400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define BTEFY_RX_UUID      "6e400002-B5A3-F393-E0A9-E50E24DCCA9E" // webpage -> ESP32
#define BTEFY_TX_UUID      "6e400003-B5A3-F393-E0A9-E50E24DCCA9E" // ESP32 -> webpage

// BLE notify payload is tiny: long lines are chunked, never truncated.
#define BTEFY_CHUNK_SIZE 20

class BTEfyDebug {
public:
  /** Start BLE UART. Call once in setup(). */
  void begin(const char *deviceName = "BTEfy-ESP32",
             const char *version = "1.0.0");

  /** Mirror everything to USB Serial as well (default: on). */
  void mirrorSerial(bool on);

  /** True while a BLE client (the webpage) is connected. */
  bool connected();

  void println(const char *msg);
  void println(const String &msg);
  void println(int v);
  void println(float v, int decimals = 2);

  void print(const char *msg);
  void print(const String &msg);

  /** Tagged log line: [TAG] message */
  void log(const char *tag, const char *msg);

  /** Telemetry line BTEfy auto-plots: TEMP=25.40 */
  void metric(const char *key, float value, int decimals = 2);

  /** printf-style: BTEfy.logf("MOTOR", "rpm=%d", rpm); */
  void logf(const char *tag, const char *fmt, ...);

private:
  /** Incoming commands from the webpage (PING / STATUS / VERSION / echo). */
  class RxCallbacks : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic *chr, NimBLEConnInfo &connInfo) override;
  };

  void sendLine(const char *msg);
  void sendRaw(const char *msg);

  NimBLECharacteristic *_tx = nullptr;
  const char *_version = "1.0.0";
  bool _mirror = true;
  static BTEfyDebug *_self; // set in begin(), used by the RX callback
};

/** Global instance use BTEfy.println(...) anywhere. */
extern BTEfyDebug BTEfy;
